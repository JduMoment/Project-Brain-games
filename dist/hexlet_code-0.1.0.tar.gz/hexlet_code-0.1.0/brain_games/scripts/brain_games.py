#!/usr/bin/env python3


from brain_games.cli import welcome_user
from brain_games.cli import name
from brain_games.even_game import even_odd_game


def main():
    print('Welcome to the Brain Games!')
    print('Hello, ' + name + '!')
    even_odd_game()


if __name__ == '__main__':
    main()
