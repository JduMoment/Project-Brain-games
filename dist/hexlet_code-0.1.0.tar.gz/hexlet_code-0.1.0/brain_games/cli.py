import prompt

name = welcome_user()

def welcome_user():
    name = prompt.string('May I have your name? ')
    return name
