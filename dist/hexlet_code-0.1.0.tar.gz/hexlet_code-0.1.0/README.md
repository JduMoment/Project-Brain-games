### Hexlet tests and linter status:
[![Actions Status](https://github.com/JduMoment/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/JduMoment/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2dd93f32b0994a1d1010/maintainability)](https://codeclimate.com/github/JduMoment/python-project-49/maintainability)
Вот тут можно посмотреть аскинему с примером установки пакета и игрой чётно-нечётно: https://asciinema.org/a/SqZKdMwO14G9bxOtegGd6GKEA
Вот тут можно посмотреть калькуляцию: https://asciinema.org/a/oDvd2aqzRFf70789t9i0tuKcn
