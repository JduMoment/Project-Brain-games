#!/usr/bin/env python3


from brain_games.games.arithm_progress_game import arithm_progress


def main():
    arithm_progress()


if __name__ == '__main__':
    main()
    